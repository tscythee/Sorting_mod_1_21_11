package com.scythe.sorting;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import org.lwjgl.glfw.GLFW;
import com.mojang.blaze3d.platform.InputConstants;

public class ScytheSortingClient implements ClientModInitializer {
    public static final String MOD_ID = "scythe-sorting";
    private static KeyMapping sortKey;

    @Override
    public void onInitializeClient() {
        // Na 1.21.11, o construtor do KeyMapping mudou. 
        // Usamos o construtor que aceita (String, Type, int, String) que o Fabric mapeia.
        sortKey = KeyBindingHelper.registerKeyBinding(new KeyMapping(
                "key.scythe-sorting.sort",
                InputConstants.Type.KEYSYM,
                GLFW.GLFW_KEY_R,
                "key.categories.inventory"
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (sortKey.consumeClick()) {
                if (client.screen instanceof AbstractContainerScreen<?> screen) {
                    InventorySorter.sort(screen);
                }
            }
        });
    }
}
