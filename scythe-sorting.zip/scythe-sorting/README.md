# Scythe Sorting (SS)

Mod client-side de ordenação de inventário para Fabric, Minecraft **1.21.11**.

Não precisa de nada instalado no servidor — o mod só simula cliques normais
de mouse (o mesmo que um jogador faria manualmente), então funciona em
qualquer servidor vanilla.

## Novidades desta versão

- **Botão com ícone de verdade** (16x16, `textures/gui/sort_icon.png`),
  centrado corretamente em cima do fundo vanilla do botão, com posição
  calculada e "grudada na tela" (nunca renderiza fora da GUI, em nenhuma
  GUI Scale).
- **Posição do botão configurável**: canto superior/inferior, direito/
  esquerdo (`buttonCorner` no config, ou pela tela de configurações).
- **Tela de configuração in-game** (`ScytheConfigScreen`) — não precisa
  mais editar JSON na mão. Abre por:
  - Mod Menu, se estiver instalado (integração opcional, ver abaixo);
  - Uma keybind própria "Open Scythe Sorting Config" (sem tecla padrão,
    configure em Controles).
- **Trocar modo de ordenação sem abrir menu**:
  - Keybind "Next Sorting Mode" (sem tecla padrão, configure em Controles);
  - Shift + clique no botão de ordenar também cicla o modo.
  - Mostra o modo novo na Action Bar ("Sorting Mode: Smart", etc.).
- **Som de clique vanilla** (`UI_BUTTON_CLICK`) ao ordenar ou trocar de
  modo, configurável (liga/desliga).
- Tudo salva automaticamente em `config/scythesorting.json` e aplica na
  hora, sem precisar reiniciar o jogo.

## Integração opcional com Mod Menu

O mod **não exige** o Mod Menu instalado. Se ele estiver presente, um
ícone de engrenagem aparece na tela de mods abrindo a mesma tela de
configuração. Isso é feito via `modCompileOnly` no Gradle — ou seja, o
Mod Menu não é baixado nem embutido no seu `.jar`, só é usado durante a
compilação para o código entender a API dele.

## Estrutura

```
src/main/java/com/scyther/scythesorting/
  ScytheSorting.java              -> entrypoint client, keybinds, botão, hover
  config/ScytheConfig.java        -> config JSON
  config/ButtonCorner.java        -> posição do botão
  gui/SortButtonWidget.java       -> botão com ícone (renderWidget)
  gui/ScytheConfigScreen.java     -> tela de config in-game
  integration/ScytheModMenuIntegration.java -> só carrega se Mod Menu existir
  sort/SortMode.java
  sort/ItemCategorizer.java       -> heurísticas de categoria (id do item)
  sort/InventorySorter.java       -> algoritmo de ordenação (cliques simulados)
  mixin/ScreenAccessor.java          -> invoker p/ addDrawableChild (protected)
  mixin/HandledScreenAccessor.java   -> accessor p/ x/y/backgroundWidth/Height
```

Só existem 2 mixins, e os dois são **accessors/invokers simples** — não
mexem em lógica de jogo, mantendo a build estável e fácil de compilar.

## Como compilar pelo Termux

```bash
pkg install openjdk-21 -y
cd ~/scythe-sorting
sed -i 's/^org.gradle.jvmargs=.*/org.gradle.jvmargs=-Xmx1G/' gradle.properties
gradle --stop
gradle build
```

O `.jar` final aparece em `build/libs/scythe-sorting-1.0.0.jar`. Copie
esse arquivo, e o `fabric-api` (dependência obrigatória), para a pasta
`mods/` da sua instância Fabric 1.21.11.

> **Importante:** eu não tenho acesso à internet neste ambiente, então não
> consigo rodar `./gradlew build` de fato para confirmar a compilação. As
> assinaturas de API (DrawContext, CyclingButtonWidget, KeyBinding.Category,
> PositionedSoundInstance etc.) foram conferidas na documentação oficial da
> Yarn/Fabric agora em julho/2026, mas se algum nome de método/campo tiver
> mudado entre builds específicos, pode aparecer erro pontual — me manda o
> log que eu ajusto na hora.

## Se quiser mexer nas versões

Tudo fica em `gradle.properties`. Não precisa tocar em mais nada.
