package com.scyther.scythesorting.mixin;

import net.minecraft.client.gui.Drawable;
import net.minecraft.client.gui.Element;
import net.minecraft.client.gui.Selectable;
import net.minecraft.client.gui.screen.Screen;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

/**
 * Screen#addDrawableChild is protected, so we expose it through a simple
 * mixin invoker to be able to add our sort button to any vanilla screen.
 */
@Mixin(Screen.class)
public interface ScreenAccessor {

    @Invoker("addDrawableChild")
    <T extends Element & Drawable & Selectable> T scytheSorting$addDrawableChild(T drawable);
}
