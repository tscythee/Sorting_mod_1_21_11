package com.scyther.scythesorting.sort;

import net.minecraft.component.DataComponentTypes;
import net.minecraft.item.BlockItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;

/**
 * Lightweight, dependency-free heuristics for grouping items.
 * <p>
 * NOTE: as of the 1.21.5+ item rework, Mojang removed the SwordItem /
 * PickaxeItem / AxeItem / ArmorItem / ToolItem class hierarchy - tools,
 * weapons and armor are now identified through data components (WEAPON,
 * TOOL, EQUIPPABLE) rather than a Java subclass. To stay simple and not
 * depend on exact component shapes (which keep changing release to
 * release), this categorizer instead looks at the item's registry id,
 * which is stable and easy to reason about.
 */
public final class ItemCategorizer {

    private ItemCategorizer() {
    }

    public static boolean isBlock(ItemStack stack) {
        return stack.getItem() instanceof BlockItem;
    }

    public static boolean isFood(ItemStack stack) {
        return stack.contains(DataComponentTypes.FOOD);
    }

    public static boolean isPickaxe(String id) {
        return id.endsWith("_pickaxe");
    }

    public static boolean isAxe(String id) {
        return id.endsWith("_axe") && !id.endsWith("_pickaxe");
    }

    public static boolean isShovel(String id) {
        return id.endsWith("_shovel");
    }

    public static boolean isHoe(String id) {
        return id.endsWith("_hoe");
    }

    public static boolean isSword(String id) {
        return id.endsWith("_sword");
    }

    public static boolean isRangedWeapon(String id) {
        return id.equals("bow") || id.equals("crossbow") || id.equals("trident") || id.equals("mace");
    }

    public static boolean isTool(String id) {
        return isPickaxe(id) || isAxe(id) || isShovel(id) || isHoe(id)
                || id.equals("shears") || id.equals("fishing_rod") || id.equals("flint_and_steel");
    }

    public static boolean isWeapon(String id) {
        return isSword(id) || isRangedWeapon(id);
    }

    public static boolean isShield(String id) {
        return id.equals("shield");
    }

    public static boolean isArmor(String id) {
        return id.endsWith("_helmet") || id.endsWith("_chestplate")
                || id.endsWith("_leggings") || id.endsWith("_boots")
                || id.equals("elytra") || id.endsWith("_horse_armor");
    }

    /** Lower value = higher priority (appears first). */
    public static int equipmentRank(ItemStack stack) {
        String id = idOf(stack.getItem());
        if (isArmor(id) || isShield(id)) return 0;
        if (isWeapon(id)) return 1;
        if (isTool(id)) return 2;
        return 9;
    }

    /** Lower value = higher priority (appears first). */
    public static int resourceRank(ItemStack stack) {
        String id = idOf(stack.getItem());
        if (id.contains("netherite")) return 0;
        if (id.contains("diamond")) return 1;
        if (id.contains("emerald")) return 2;
        if (id.contains("gold")) return 3;
        if (id.contains("iron")) return 4;
        if (id.contains("copper")) return 5;
        if (id.contains("coal")) return 6;
        if (id.contains("redstone")) return 7;
        if (id.contains("quartz")) return 8;
        if (id.contains("ore")) return 1;
        if (id.contains("ingot") || id.contains("nugget")) return 3;
        return 9;
    }

    /** Lower value = higher priority (appears first). Used by "Smart Sorting". */
    public static int smartRank(ItemStack stack) {
        Item item = stack.getItem();
        String id = idOf(item);

        if (item instanceof BlockItem) {
            if (id.contains("ore")) return 1;
            return 0;
        }
        if (id.contains("ore")) return 1;
        if (id.contains("ingot") || id.contains("nugget")) return 3;
        if (id.contains("diamond") || id.contains("emerald") || id.contains("quartz")
                || id.contains("amethyst") || id.contains("lapis")) return 4;
        if (isArmor(id)) return 8;
        if (isWeapon(id)) return 7;
        if (isTool(id) || isShield(id)) return 6;
        if (isFood(stack)) return 9;
        if (id.contains("seed") || id.contains("crop") || id.contains("wheat")
                || id.contains("sapling")) return 10;
        if (id.contains("redstone") || id.contains("repeater") || id.contains("comparator")
                || id.contains("piston") || id.contains("hopper") || id.contains("dispenser")) return 11;
        return 12;
    }

    private static String idOf(Item item) {
        return Registries.ITEM.getId(item).getPath();
    }
}
