package com.scyther.scythesorting.sort;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.screen.ScreenHandler;
import net.minecraft.screen.slot.Slot;
import net.minecraft.screen.slot.SlotActionType;

import java.util.Comparator;
import java.util.List;
import java.util.Locale;

/**
 * Sorts a list of slots that all belong to the SAME backing inventory
 * (either the currently open container, or the player's own inventory).
 * <p>
 * Everything is done through normal clickSlot() calls, exactly like a
 * player using the mouse - no server-side mod, no direct ItemStack edits,
 * no duplication or deletion.
 */
public final class InventorySorter {

    private InventorySorter() {
    }

    public static void sort(MinecraftClient client, ScreenHandler handler, List<Slot> slots, SortMode mode) {
        if (client == null || client.player == null || client.interactionManager == null) return;
        if (slots.size() < 2) return;

        ClientPlayerEntity player = client.player;
        int syncId = handler.syncId;

        // 1) Merge identical stacks first (respects max stack size, NBT/components, etc.)
        consolidate(client, syncId, slots, player);

        // 2) Selection-sort the slots in place using the same safe 3-click swap.
        Comparator<Slot> comparator = buildComparator(mode);
        int n = slots.size();
        for (int i = 0; i < n; i++) {
            int best = i;
            for (int j = i + 1; j < n; j++) {
                if (comparator.compare(slots.get(j), slots.get(best)) < 0) {
                    best = j;
                }
            }
            if (best != i) {
                swap(client, syncId, slots.get(i), slots.get(best), player);
            }
        }
    }

    private static void consolidate(MinecraftClient client, int syncId, List<Slot> slots, ClientPlayerEntity player) {
        int n = slots.size();
        for (int i = 0; i < n; i++) {
            Slot a = slots.get(i);
            if (a.getStack().isEmpty()) continue;
            if (a.getStack().getCount() >= a.getStack().getMaxCount()) continue;

            for (int j = i + 1; j < n; j++) {
                Slot b = slots.get(j);
                ItemStack bs = b.getStack();
                if (bs.isEmpty()) continue;
                if (!ItemStack.areItemsAndComponentsEqual(a.getStack(), bs)) continue;

                // Swapping two slots holding the same item merges them (with any
                // overflow correctly placed back), so we reuse the same primitive.
                swap(client, syncId, a, b, player);

                if (a.getStack().getCount() >= a.getStack().getMaxCount()) break;
            }
        }
    }

    /**
     * Classic 3-click swap: pickup A, pickup B (drops A into B, merging or
     * swapping as vanilla normally would), pickup A again (drops whatever
     * is left in the cursor back into A). Works for empty slots too.
     */
    private static void swap(MinecraftClient client, int syncId, Slot a, Slot b, ClientPlayerEntity player) {
        client.interactionManager.clickSlot(syncId, a.id, 0, SlotActionType.PICKUP, player);
        client.interactionManager.clickSlot(syncId, b.id, 0, SlotActionType.PICKUP, player);
        client.interactionManager.clickSlot(syncId, a.id, 0, SlotActionType.PICKUP, player);
    }

    private static Comparator<Slot> buildComparator(SortMode mode) {
        Comparator<Slot> emptyLast = Comparator.comparing(s -> s.getStack().isEmpty());

        Comparator<Slot> byMode = switch (mode) {
            case QUANTITY -> Comparator.comparingInt(s -> -((Slot) s).getStack().getCount());
            case ALPHABETICAL -> Comparator.comparing(InventorySorter::itemName);
            case BLOCKS_FIRST -> Comparator.<Slot>comparingInt(s -> ItemCategorizer.isBlock(s.getStack()) ? 0 : 1)
                    .thenComparing(InventorySorter::itemName);
            case EQUIPMENT_FIRST -> Comparator.<Slot>comparingInt(s -> ItemCategorizer.equipmentRank(s.getStack()))
                    .thenComparing(InventorySorter::itemName);
            case RESOURCES_FIRST -> Comparator.<Slot>comparingInt(s -> ItemCategorizer.resourceRank(s.getStack()))
                    .thenComparing(InventorySorter::itemName);
            case SMART -> Comparator.<Slot>comparingInt(s -> ItemCategorizer.smartRank(s.getStack()))
                    .thenComparing(InventorySorter::itemName);
        };

        return emptyLast.thenComparing(byMode);
    }

    private static String itemName(Slot slot) {
        ItemStack stack = slot.getStack();
        return stack.isEmpty() ? "" : stack.getName().getString().toLowerCase(Locale.ROOT);
    }
}
