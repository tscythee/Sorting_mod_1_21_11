package com.scyther.scythesorting.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonSyntaxException;
import com.scyther.scythesorting.sort.SortMode;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

public class ScytheConfig {

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path PATH = FabricLoader.getInstance().getConfigDir().resolve("scythesorting.json");
    private static ScytheConfig instance;

    // --- Options ---
    public boolean enableButton = true;
    public boolean enableHotkey = true;
    public boolean enableStackMerging = true;
    public boolean enableSound = true;
    public boolean rememberLastMode = true;
    public SortMode defaultMode = SortMode.SMART;
    public ButtonCorner buttonCorner = ButtonCorner.TOP_RIGHT;

    public static ScytheConfig get() {
        if (instance == null) {
            instance = load();
        }
        return instance;
    }

    public SortMode activeMode() {
        return rememberLastMode ? defaultMode : SortMode.SMART;
    }

    /** Advances to the next sorting mode and persists it immediately. */
    public SortMode cycleMode() {
        defaultMode = defaultMode.next();
        save();
        return defaultMode;
    }

    private static ScytheConfig load() {
        try {
            if (Files.exists(PATH)) {
                String json = Files.readString(PATH);
                ScytheConfig loaded = GSON.fromJson(json, ScytheConfig.class);
                if (loaded != null) return loaded;
            }
        } catch (IOException | JsonSyntaxException ignored) {
            // fall back to defaults below
        }
        ScytheConfig fresh = new ScytheConfig();
        fresh.save();
        return fresh;
    }

    public void save() {
        try {
            Files.createDirectories(PATH.getParent());
            Files.writeString(PATH, GSON.toJson(this));
        } catch (IOException ignored) {
            // non-fatal: worst case, defaults are used next launch
        }
    }
}
