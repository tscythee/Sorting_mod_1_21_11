package com.scyther.scythesorting.sort;

import net.minecraft.text.Text;

public enum SortMode {
    SMART,
    QUANTITY,
    ALPHABETICAL,
    BLOCKS_FIRST,
    EQUIPMENT_FIRST,
    RESOURCES_FIRST;

    private static final SortMode[] VALUES = values();

    public SortMode next() {
        return VALUES[(this.ordinal() + 1) % VALUES.length];
    }

    /** Translatable label, e.g. "scythesorting.mode.smart" -> "Smart". */
    public Text displayName() {
        return Text.translatable("scythesorting.mode." + name().toLowerCase());
    }
}
