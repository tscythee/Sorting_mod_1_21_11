package com.scyther.scythesorting.config;

import net.minecraft.text.Text;

/** Which corner of the container box the sort button should anchor to. */
public enum ButtonCorner {
    TOP_RIGHT,
    TOP_LEFT,
    BOTTOM_RIGHT,
    BOTTOM_LEFT;

    public Text displayName() {
        return Text.translatable("scythesorting.corner." + name().toLowerCase());
    }
}
