package com.scyther.scythesorting.integration;

import com.scyther.scythesorting.gui.ScytheConfigScreen;
import com.terraformersmc.modmenu.api.ConfigScreenFactory;
import com.terraformersmc.modmenu.api.ModMenuApi;

/**
 * Registered under the "modmenu" entrypoint in fabric.mod.json. Mod Menu
 * only looks this up if it is actually installed, so this class never
 * needs to load (and this mod never needs to depend on Mod Menu at
 * runtime) if the player doesn't have it.
 */
public class ScytheModMenuIntegration implements ModMenuApi {

    @Override
    public ConfigScreenFactory<?> getModConfigScreenFactory() {
        return ScytheConfigScreen::new;
    }
}
