package com.scyther.scythesorting;

import com.scyther.scythesorting.config.ButtonCorner;
import com.scyther.scythesorting.config.ScytheConfig;
import com.scyther.scythesorting.gui.ScytheConfigScreen;
import com.scyther.scythesorting.gui.SortButtonWidget;
import com.scyther.scythesorting.mixin.HandledScreenAccessor;
import com.scyther.scythesorting.mixin.ScreenAccessor;
import com.scyther.scythesorting.sort.InventorySorter;
import com.scyther.scythesorting.sort.SortMode;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.ingame.HandledScreen;
import net.minecraft.client.gui.tooltip.Tooltip;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.sound.PositionedSoundInstance;
import net.minecraft.client.util.InputUtil;
import net.minecraft.screen.ScreenHandler;
import net.minecraft.screen.slot.Slot;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;

public class ScytheSorting implements ClientModInitializer {

    public static final String MOD_ID = "scythesorting";

    private static final KeyBinding.Category CATEGORY =
            KeyBinding.Category.create(Identifier.of(MOD_ID, "main"));

    private static KeyBinding sortKey;
    private static KeyBinding nextModeKey;
    private static KeyBinding openConfigKey;

    @Override
    public void onInitializeClient() {
        // Touch the config once on startup so the file gets created.
        ScytheConfig.get();

        sortKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.scythesorting.sort",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_R,
                CATEGORY
        ));

        nextModeKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.scythesorting.next_mode",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_UNKNOWN,
                CATEGORY
        ));

        openConfigKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.scythesorting.open_config",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_UNKNOWN,
                CATEGORY
        ));

        ScreenEvents.AFTER_INIT.register(this::onScreenInit);

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (sortKey != null && sortKey.wasPressed()) {
                if (ScytheConfig.get().enableHotkey) {
                    handleHotkeySort(client);
                }
            }
            while (nextModeKey != null && nextModeKey.wasPressed()) {
                cycleModeAndNotify(client);
            }
            while (openConfigKey != null && openConfigKey.wasPressed()) {
                if (client.currentScreen == null) {
                    client.setScreen(new ScytheConfigScreen(null));
                }
            }
        });
    }

    private void onScreenInit(MinecraftClient client, Screen screen, int scaledWidth, int scaledHeight) {
        if (!ScytheConfig.get().enableButton) return;
        if (!(screen instanceof HandledScreen<?> handledScreen)) return;

        HandledScreenAccessor accessor = (HandledScreenAccessor) screen;
        int boxX = accessor.scytheSorting$getX();
        int boxY = accessor.scytheSorting$getY();
        int boxW = accessor.scytheSorting$getBackgroundWidth();
        int boxH = accessor.scytheSorting$getBackgroundHeight();

        int[] pos = computeButtonPosition(ScytheConfig.get().buttonCorner, boxX, boxY, boxW, boxH, scaledWidth, scaledHeight);

        SortButtonWidget sortButton = new SortButtonWidget(pos[0], pos[1], button ->
                onButtonPressed(handledScreen, client)
        );
        sortButton.setTooltip(Tooltip.of(Text.translatable("scythesorting.button.tooltip")));

        ((ScreenAccessor) screen).scytheSorting$addDrawableChild(sortButton);
    }

    /**
     * Anchors the button to a corner of the container box, then clamps it so it
     * always stays fully on-screen regardless of GUI scale or screen size.
     */
    private static int[] computeButtonPosition(ButtonCorner corner, int boxX, int boxY, int boxW, int boxH, int scaledWidth, int scaledHeight) {
        int size = 18;
        int x;
        int y;

        boolean right = corner == ButtonCorner.TOP_RIGHT || corner == ButtonCorner.BOTTOM_RIGHT;
        boolean top = corner == ButtonCorner.TOP_RIGHT || corner == ButtonCorner.TOP_LEFT;

        x = right ? (boxX + boxW - size) : boxX;
        y = top ? (boxY - size - 2) : (boxY + boxH + 2);

        // If there isn't room above/below the box, fall back to just inside the box edge.
        if (top && y < 2) {
            y = boxY + 2;
        }
        if (!top && y + size > scaledHeight - 2) {
            y = boxY + boxH - size - 2;
        }

        // Final safety clamp so the button can never render off-screen.
        x = Math.max(2, Math.min(x, scaledWidth - size - 2));
        y = Math.max(2, Math.min(y, scaledHeight - size - 2));

        return new int[]{x, y};
    }

    private static void onButtonPressed(HandledScreen<?> screen, MinecraftClient client) {
        if (isShiftDown(client)) {
            cycleModeAndNotify(client);
        } else {
            performFullSort(screen);
            playClickSound(client);
        }
    }

    /** Low-level shift check via raw GLFW - stable across Minecraft/Yarn versions. */
    private static boolean isShiftDown(MinecraftClient client) {
        if (client.getWindow() == null) return false;
        long handle = client.getWindow().getHandle();
        return GLFW.glfwGetKey(handle, GLFW.GLFW_KEY_LEFT_SHIFT) == GLFW.GLFW_PRESS
                || GLFW.glfwGetKey(handle, GLFW.GLFW_KEY_RIGHT_SHIFT) == GLFW.GLFW_PRESS;
    }

    private static void cycleModeAndNotify(MinecraftClient client) {
        SortMode newMode = ScytheConfig.get().cycleMode();
        playClickSound(client);
        if (client.player != null) {
            client.player.sendMessage(
                    Text.translatable("scythesorting.mode_changed", newMode.displayName()),
                    true
            );
        }
    }

    private static void playClickSound(MinecraftClient client) {
        if (!ScytheConfig.get().enableSound) return;
        client.getSoundManager().play(PositionedSoundInstance.ui(SoundEvents.UI_BUTTON_CLICK, 1.0F));
    }

    /** Sorts only whichever inventory (container or player) the mouse is currently hovering over. */
    private static void handleHotkeySort(MinecraftClient client) {
        if (!(client.currentScreen instanceof HandledScreen<?> handledScreen)) return;
        if (client.player == null || client.mouse == null || client.getWindow() == null) return;

        double mouseX = client.mouse.getX() * (double) client.getWindow().getScaledWidth() / client.getWindow().getWidth();
        double mouseY = client.mouse.getY() * (double) client.getWindow().getScaledHeight() / client.getWindow().getHeight();

        HandledScreenAccessor accessor = (HandledScreenAccessor) handledScreen;
        int originX = accessor.scytheSorting$getX();
        int originY = accessor.scytheSorting$getY();

        ScreenHandler handler = handledScreen.getScreenHandler();
        Slot hovered = null;
        for (Slot slot : handler.slots) {
            int sx = originX + slot.x;
            int sy = originY + slot.y;
            if (mouseX >= sx - 1 && mouseX < sx + 17 && mouseY >= sy - 1 && mouseY < sy + 17) {
                hovered = slot;
                break;
            }
        }
        if (hovered == null) return; // mouse outside any inventory area -> do nothing

        boolean isPlayerInventory = hovered.inventory == client.player.getInventory();
        List<Slot> target = collectSlots(handler, isPlayerInventory, client);
        if (!target.isEmpty()) {
            InventorySorter.sort(client, handler, target, ScytheConfig.get().activeMode());
            playClickSound(client);
        }
    }

    /** Sorts the container side and the player-inventory side independently. */
    private static void performFullSort(HandledScreen<?> screen) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player == null) return;
        ScreenHandler handler = screen.getScreenHandler();

        List<Slot> containerSlots = collectSlots(handler, false, client);
        List<Slot> playerSlots = collectSlots(handler, true, client);

        if (!containerSlots.isEmpty()) {
            InventorySorter.sort(client, handler, containerSlots, ScytheConfig.get().activeMode());
        }
        if (!playerSlots.isEmpty()) {
            InventorySorter.sort(client, handler, playerSlots, ScytheConfig.get().activeMode());
        }
    }

    /**
     * Only plain vanilla Slot instances are collected - this deliberately skips
     * armor slots, offhand, crafting result slots, merchant slots, etc. so the
     * sorter never touches anything that isn't a simple storage slot.
     */
    private static List<Slot> collectSlots(ScreenHandler handler, boolean playerInventory, MinecraftClient client) {
        List<Slot> result = new ArrayList<>();
        for (Slot slot : handler.slots) {
            if (slot.getClass() != Slot.class) continue;
            boolean belongsToPlayer = slot.inventory == client.player.getInventory();
            if (belongsToPlayer == playerInventory) {
                result.add(slot);
            }
        }
        return result;
    }
}
