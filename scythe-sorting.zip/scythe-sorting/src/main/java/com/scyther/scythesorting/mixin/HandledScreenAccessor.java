package com.scyther.scythesorting.mixin;

import net.minecraft.client.gui.screen.ingame.HandledScreen;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

/**
 * x/y/backgroundWidth/backgroundHeight are protected fields on HandledScreen.
 * We only read them to position the sort button correctly on any container GUI.
 */
@Mixin(HandledScreen.class)
public interface HandledScreenAccessor {

    @Accessor("x")
    int scytheSorting$getX();

    @Accessor("y")
    int scytheSorting$getY();

    @Accessor("backgroundWidth")
    int scytheSorting$getBackgroundWidth();

    @Accessor("backgroundHeight")
    int scytheSorting$getBackgroundHeight();
}
