package com.scyther.scythesorting.gui;

import com.scyther.scythesorting.config.ButtonCorner;
import com.scyther.scythesorting.config.ScytheConfig;
import com.scyther.scythesorting.sort.SortMode;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.ClickableWidget;
import net.minecraft.client.gui.widget.CyclingButtonWidget;
import net.minecraft.text.Text;

/**
 * Lightweight, self-contained config screen - no Cloth Config / Mod Menu
 * dependency required at runtime. Every widget writes straight into the
 * live ScytheConfig instance and persists it to disk immediately, so
 * changes apply without restarting the game.
 */
public class ScytheConfigScreen extends Screen {

    private static final int ROW_HEIGHT = 24;
    private static final int ROW_WIDTH = 240;

    private final Screen parent;
    private final ScytheConfig config;

    public ScytheConfigScreen(Screen parent) {
        super(Text.translatable("scythesorting.config.title"));
        this.parent = parent;
        this.config = ScytheConfig.get();
    }

    @Override
    protected void init() {
        int centerX = this.width / 2;
        int y = this.height / 2 - (ROW_HEIGHT * 4);

        addRow(CyclingButtonWidget.<SortMode>builder(SortMode::displayName, config.defaultMode)
                .values(SortMode.values())
                .build(centerX - ROW_WIDTH / 2, y, ROW_WIDTH, 20,
                        Text.translatable("scythesorting.config.default_mode"),
                        (btn, value) -> {
                            config.defaultMode = value;
                            config.save();
                        }));
        y += ROW_HEIGHT;

        addRow(CyclingButtonWidget.onOffBuilder(config.enableButton)
                .build(centerX - ROW_WIDTH / 2, y, ROW_WIDTH, 20,
                        Text.translatable("scythesorting.config.enable_button"),
                        (btn, value) -> {
                            config.enableButton = value;
                            config.save();
                        }));
        y += ROW_HEIGHT;

        addRow(CyclingButtonWidget.<ButtonCorner>builder(ButtonCorner::displayName, config.buttonCorner)
                .values(ButtonCorner.values())
                .build(centerX - ROW_WIDTH / 2, y, ROW_WIDTH, 20,
                        Text.translatable("scythesorting.config.button_corner"),
                        (btn, value) -> {
                            config.buttonCorner = value;
                            config.save();
                        }));
        y += ROW_HEIGHT;

        addRow(CyclingButtonWidget.onOffBuilder(config.enableHotkey)
                .build(centerX - ROW_WIDTH / 2, y, ROW_WIDTH, 20,
                        Text.translatable("scythesorting.config.enable_hotkey"),
                        (btn, value) -> {
                            config.enableHotkey = value;
                            config.save();
                        }));
        y += ROW_HEIGHT;

        addRow(CyclingButtonWidget.onOffBuilder(config.enableStackMerging)
                .build(centerX - ROW_WIDTH / 2, y, ROW_WIDTH, 20,
                        Text.translatable("scythesorting.config.enable_merging"),
                        (btn, value) -> {
                            config.enableStackMerging = value;
                            config.save();
                        }));
        y += ROW_HEIGHT;

        addRow(CyclingButtonWidget.onOffBuilder(config.enableSound)
                .build(centerX - ROW_WIDTH / 2, y, ROW_WIDTH, 20,
                        Text.translatable("scythesorting.config.enable_sound"),
                        (btn, value) -> {
                            config.enableSound = value;
                            config.save();
                        }));
        y += ROW_HEIGHT;

        addRow(CyclingButtonWidget.onOffBuilder(config.rememberLastMode)
                .build(centerX - ROW_WIDTH / 2, y, ROW_WIDTH, 20,
                        Text.translatable("scythesorting.config.remember_mode"),
                        (btn, value) -> {
                            config.rememberLastMode = value;
                            config.save();
                        }));
        y += ROW_HEIGHT + 10;

        addDrawableChild(ButtonWidget.builder(Text.translatable("gui.done"), b -> close())
                .dimensions(centerX - 75, y, 150, 20).build());
    }

    private void addRow(ClickableWidget widget) {
        addDrawableChild(widget);
    }

    @Override
    public void close() {
        config.save();
        if (this.client != null) {
            this.client.setScreen(parent);
        }
    }

    @Override
    public boolean shouldPause() {
        return false;
    }
}
