package com.scyther.scythesorting.gui;

import net.minecraft.client.gl.RenderPipelines;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

/**
 * A small (18x18) vanilla-styled button. PressableWidget in this version
 * renders the background/text itself (renderWidget is final) and exposes
 * drawIcon(...) as the hook for subclasses to draw extra content on top,
 * which is where we draw our 16x16 sort icon, centered.
 */
public class SortButtonWidget extends ButtonWidget {

    private static final Identifier ICON = Identifier.of("scythesorting", "textures/gui/sort_icon.png");
    private static final int ICON_SIZE = 16;

    public SortButtonWidget(int x, int y, PressAction onPress) {
        super(x, y, 18, 18, Text.translatable("scythesorting.button.label"), onPress, DEFAULT_NARRATION_SUPPLIER);
    }

    @Override
    protected void drawIcon(DrawContext context, int mouseX, int mouseY, float delta) {
        int iconX = getX() + (getWidth() - ICON_SIZE) / 2;
        int iconY = getY() + (getHeight() - ICON_SIZE) / 2;
        context.drawTexture(RenderPipelines.GUI_TEXTURED, ICON, iconX, iconY, 0, 0, ICON_SIZE, ICON_SIZE, ICON_SIZE, ICON_SIZE);
    }
}
