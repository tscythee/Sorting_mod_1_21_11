package com.scythe.sorting;

import com.scythe.sorting.mixin.AbstractContainerScreenAccessor;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.ItemStack;

import java.util.*;
import java.util.stream.Collectors;

public class InventorySorter {

    public static void sort(AbstractContainerScreen<?> screen) {
        Minecraft client = Minecraft.getInstance();
        if (client.player == null) return;

        // Uso do Accessor para pegar o slot sob o mouse
        Slot hoveredSlot = ((AbstractContainerScreenAccessor) screen).scythe_getSlotUnderMouse();
        if (hoveredSlot == null) return;

        boolean isPlayerInventory = hoveredSlot.container == client.player.getInventory();
        
        List<Slot> slotsToSort = new ArrayList<>();
        for (Slot slot : screen.getMenu().slots) {
            if (isPlayerInventory) {
                if (slot.container == client.player.getInventory() && slot.getContainerSlot() >= 9 && slot.getContainerSlot() < 36) {
                    slotsToSort.add(slot);
                }
            } else {
                if (slot.container != client.player.getInventory()) {
                    slotsToSort.add(slot);
                }
            }
        }

        if (slotsToSort.isEmpty()) return;

        // A lógica de ordenação e movimentação de itens seria implementada aqui
    }
}
